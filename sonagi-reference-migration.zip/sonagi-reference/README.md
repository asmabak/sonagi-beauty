# sonagi-reference

> the K-beauty encyclopedia behind sonagibeauty.com/ref · 365-entry institutional reference · the Feynman of beauty.

Source of truth for every encyclopedia entry on sonagibeauty.com/ref. Bilingual (FR primary, EN secondary). Markdown sources + YAML frontmatter, build pipeline generates HTML + JSON-LD + sitemap + RSS + GraphQL schema + llms.txt.

**Protocol pages** (Notion, authoritative):

- 📖 Sonagi Reference Programme — overall programme owner, eight workstreams, master timeline
- 🗄️ Content & Asset Management Architecture — repo structure, entry format, editorial workflow, asset rules
- 🖼️ Image & Diagram Protocol — generation, naming, sidecar JSON, variants, licence audit
- 📋 Shared Context (brand layer) — voice rules, palette, fonts, forbidden words, content pillars
- 💾 State Persistence Protocol — checkpoint cadence, recovery procedure
- 🚀 Deployment & Source of Truth Rules — live-is-canonical, drift detection

## getting started

Read these in order before contributing:

1. `STYLE_GUIDE.md` — editorial voice, no em-dashes, lowercase, the Feynman of beauty register
2. `CONTRIBUTING.md` — branching, PR, validation chain
3. `SCHEMA_REFERENCE.md` — what every entry type requires
4. `assets/_images-to-fetch.md` — current image fetch queue

## phase 0 status (2026-05-15)

This repository was seeded with the first 4 encyclopedia entries by a Claude Code session running on the `sonagi-beauty` repo. The session migrated content that had been incorrectly built in `sonagi-beauty/files/encyclopedie/` into protocol-compliant markdown here.

Entries seeded (FR canonical):

- `content/ingredients/fr/niacinamide.md` — 268 lines · ingredient
- `content/techniques/fr/glass-skin.md` — 230 lines · korean concept (technique)
- `content/techniques/fr/rejuran-pdrn.md` — 272 lines · clinical procedure (technique) + mandatory medical disclaimer
- `content/routines/fr/routine-anti-age.md` — 359 lines · routine

All four follow the niacinamide.md gold-standard structure: protocol YAML frontmatter, lowercase H1, intro + résumé blockquote, mechanism section with `[CITATION — verify PubMed]` stubs, integration section, recommended products section, Asma anecdote stub, rituel CTA bundle, FAQ, related entries, entry status footer.

Brand voice rules enforced absolutely on each entry:

- lowercase headings throughout
- no em-dashes in prose (preserved only inside literal `[CITATION — ...]` / `[ANECDOTE — ...]` / `[CTA — ...]` markers)
- no exclamation marks in prose
- no emoji
- "tu" form
- no forbidden words (révolutionnaire, miracle, parfait, etc.)
- preferred register: le rituel, le geste, la texture, ralentir, le moment, le soin, le matin, le soir

**To do before publish:**

1. Asma fills in every `[ANECDOTE — Asma personalize]` block with personal voice (4 blocks total).
2. Medical fact-checker replaces every `[CITATION — verify PubMed]` marker with a verified PubMed ID + URL.
3. Fetch the 24 Higgsfield images listed in `assets/_images-to-fetch.md` and drop them in their target paths.
4. Generate 3 missing Rejuran/PDRN images (hero, dermal injection depth diagram, protocol timeline) per Image & Diagram Protocol.
5. Design 3 routine-anti-age SVG timeline diagrams in Figma (morning, evening, 12-week calendar).
6. Translate all 4 entries to English (EN translations go in `content/{category}/en/`).
7. Open PR. CI validation: schema, link check, voice check.
8. `release-manager` approves merge.
9. Build pipeline deploys to sonagibeauty.com/ref.

## repo structure (per Content & Asset Management Architecture)

```
sonagi-reference/
├── README.md                    → this file
├── CONTRIBUTING.md              → contribution workflow (TO WRITE)
├── STYLE_GUIDE.md               → editorial voice (TO WRITE)
├── SCHEMA_REFERENCE.md          → entry type requirements (TO WRITE)
│
├── content/
│   ├── ingredients/
│   │   ├── fr/niacinamide.md   ✓ seeded
│   │   └── en/                  → translations pending
│   ├── techniques/
│   │   ├── fr/glass-skin.md    ✓ seeded
│   │   ├── fr/rejuran-pdrn.md  ✓ seeded
│   │   └── en/                  → translations pending
│   ├── routines/
│   │   ├── fr/routine-anti-age.md ✓ seeded
│   │   └── en/                  → translations pending
│   ├── brands/                  → TO POPULATE
│   ├── conditions/              → TO POPULATE
│   └── regulatory/              → TO POPULATE
│
├── assets/
│   ├── _images-to-fetch.md      ✓ migration manifest
│   ├── images/
│   │   ├── ingredients/
│   │   │   └── niacinamide-hero.json ✓ canonical sidecar example
│   │   ├── techniques/
│   │   ├── routines/
│   │   └── og/                  → social cards
│   ├── diagrams/
│   │   └── _sources/            → Figma sources
│   └── data/                    → JSON datasets
│
├── schemas/                     → TO POPULATE (JSON Schema validation)
├── templates/                   → TO POPULATE (HTML templates)
├── scripts/                     → TO POPULATE (build pipeline)
└── .github/workflows/           → TO POPULATE (validate.yml, deploy.yml)
```

## decisions locked (per Sonagi Reference Programme v1.2, 2026-05-13)

- domain: sonagibeauty.com/ref (subdirectory, no DNS work)
- languages: FR primary, EN secondary, AR dropped (revisit 2029+)
- pace: 1 entry per day
- voice: Feynman of beauty
- medical sources: 8-tier source list approved by Asma 2026-05-13
- positioning: both Asma and Sonagi as Reference
- repo storage: two separate GitHub repos (sonagi-beauty existing + sonagi-reference NEW)
- source of truth: live website (sonagibeauty.com/ref) canonical, repo secondary on conflict
- cost: near zero, free-tier infrastructure

## the no-mirror rule

Per Shared Context (brand layer), 2026-05-12: Notion is the only source for the brand layer. No file mirrors. If a brand decision lives in chat, in a docx, or in a repo file but not in Notion, it does not exist. GitHub stores only large files or deployable artefacts that Notion cannot hold.

The same rule applies in reverse: if an encyclopedia entry exists in `sonagi-beauty/files/encyclopedie/` (a static HTML version pre-dating this protocol), it is stale by definition. Delete from `sonagi-beauty`, do not reconcile. The canonical version lives here.

## contact

owner: `reference-design-build-lead` (programme role) · Max (programme manager) · Asma (final approvals)
