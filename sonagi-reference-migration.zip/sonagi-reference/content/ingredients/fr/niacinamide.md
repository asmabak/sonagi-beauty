---
id: niacinamide
name: niacinamide
name_korean: 나이아신아마이드
inci: Niacinamide
alternate_names:
  - vitamine B3
  - nicotinamide
molecular_formula: C6H6N2O
category: ingredient
ingredient_family:
  - vitamins
  - barrier-actives
  - depigmentants
functions:
  - sebum-regulation
  - barrier-repair
  - depigmentation
  - anti-inflammatory
  - anti-aging
concerns:
  - pores
  - eclat
  - hydratation
  - taches
  - sebum
  - rougeurs
  - premieres-rides
korean_concepts:
  - mool-gwang
  - glass-skin
skin_types:
  - peau-mixte
  - peau-grasse
  - peau-normale
  - peau-sensible
  - peau-seche
personas:
  - curieuse
  - strategique
  - reguliere
related_entries:
  - glass-skin
  - routine-anti-age
  - retinal
  - vitamine-c
  - ceramides
  - acide-hyaluronique
regulatory:
  eu_status: cosmetic (no concentration limit)
  france_status: cosmetic (typical 2 à 15 % in serums)
  korea_status: cosmetic (mfds notified)
  pregnancy_safe: true
  pregnancy_source: crat
sources:
  - title: "[CITATION — verify PubMed] Hakozaki et al., 'The effect of niacinamide on reducing cutaneous pigmentation and suppression of melanosome transfer'"
    journal: "British Journal of Dermatology"
    year: 2002
    pubmed_id: ""
  - title: "[CITATION — verify PubMed] Tanno et al., 'Nicotinamide increases biosynthesis of ceramides as well as other stratum corneum lipids'"
    journal: "British Journal of Dermatology"
    year: 2000
    pubmed_id: ""
  - title: "[CITATION — verify PubMed] Draelos et al., 'The effect of 2 % niacinamide on facial sebum production'"
    journal: "Journal of Cosmetic and Laser Therapy"
    year: 2006
    pubmed_id: ""
  - title: "[CITATION — verify PubMed] Bissett et al., 'Niacinamide: a B vitamin that improves aging facial skin appearance'"
    journal: "Dermatologic Surgery"
    year: 2005
    pubmed_id: ""
last_updated: 2026-05-09
contributors:
  - asma-bakhtar
fact_checked: false
fact_checked_by: null
medical_claims: true
human_review_required: true
content_pillar: education
featured_image: /assets/images/ingredients/niacinamide-hero.webp
featured_image_alt: "gros plan éditorial sur une peau brune profonde, rire spontané qui plisse les coins des yeux, dollop perlé de sérum déposé sur la pommette, flacon anua niacinamide 10 + TXA 4 tenu près de la mâchoire, fond banane saturé sonagi. texture cutanée préservée : pores, vellus, hâle naturel."
featured_image_source:
  tool: higgsfield
  model: nano_banana_2
  job_id: cc11b916-797c-436e-ac48-f5e131ab9b25
  resolution: 4k
  aspect_ratio: 4:5
diagram: /assets/diagrams/niacinamide-mechanism.svg
diagram_alt: "coupe de peau en perspective 3 quart montrant les trois zones d'action de la niacinamide : transfert mélanosomal au niveau du mélanocyte basal, synthèse des céramides dans la couche cornée, régulation de la glande sébacée."
gallery:
  - path: /assets/images/ingredients/niacinamide-cosrx.webp
    alt: "flacon cosrx the niacinamide 15 serum sur fond mint sonagi, peau brune profonde tenant le compte-gouttes au niveau de la pommette."
  - path: /assets/images/ingredients/niacinamide-anua.webp
    alt: "flacon anua niacinamide 10 + txa 4 sur fond banane sonagi, modèle riant à pleines dents, goutte de sérum déposée sur la pommette."
  - path: /assets/images/ingredients/niacinamide-glow-recipe.webp
    alt: "flacon glow recipe watermelon niacinamide dew drops sur fond rose sonagi, application au niveau de la pommette."
references_in_routines:
  - routine-anti-age
references_in_techniques:
  - glass-skin
seoul_validated: true
sonagi_time_context: "matin, après le toner, avant la crème et le spf. le geste s'intègre dans le rituel sonagi time sans le rallonger."
---

# niacinamide

la niacinamide est la forme amide de la vitamine B3. inci : niacinamide. formule moléculaire C₆H₆N₂O. synthétisée pour la première fois en 1873, elle entre en cosmétique dans les années 1990 quand des chercheurs de procter & gamble publient les premières études cliniques mesurant son effet sur la pigmentation et la fonction barrière.

dans la peau, elle est convertie en NAD⁺ et NADH, coenzymes centraux de la respiration cellulaire, de la synthèse des céramides et de la réparation de l'ADN. c'est cette polyvalence biochimique qui explique sa réputation d'actif couteau-suisse dans la k-beauty.

> **résumé en une phrase.** la niacinamide régule le sébum, atténue les taches, renforce la barrière. bien dosée, elle convient à 95 % des peaux.

## comment ça marche

trois mécanismes documentés, tous mesurables en laboratoire.

### 1. inhibition du transfert mélanosomal

la niacinamide ne bloque pas la production de mélanine, contrairement à l'hydroquinone ou l'arbutine. elle interfère avec le *transfert* des mélanosomes du mélanocyte vers les kératinocytes voisins. environ **35 à 68 % d'inhibition à 5 %** selon les conditions in vitro. résultat : moins de pigment livré en surface, atténuation progressive des taches post-inflammatoires et lentigos solaires.

`[CITATION — verify PubMed]` hakozaki et al., br j dermatol 2002. étude pivot du mécanisme. à vérifier avant publication.

### 2. stimulation de la synthèse de céramides

application topique de niacinamide à 2 % : augmentation mesurée de **+34 % de céramides** dans la couche cornée à 4 semaines. les céramides sont le ciment lipidique entre les cornéocytes. sans elles, la barrière fuit, l'eau s'évapore (TEWL élevé), la peau s'irrite. c'est ce mécanisme qui rend la niacinamide intéressante en pré- ou post-rétinol.

`[CITATION — verify PubMed]` tanno et al., br j dermatol 2000.

### 3. régulation du sébum

à **2 % minimum**, la niacinamide réduit la production sébacée mesurée par sébumétrie de l'ordre de **20 à 50 % à 4 semaines**. mécanisme exact encore débattu (modulation des récepteurs aux androgènes versus effet anti-inflammatoire en aval). en pratique : peaux mixtes à grasses qui voient les pores moins encombrés, brillances de zone T réduites.

`[CITATION — verify PubMed]` draelos et al., j cosmet laser ther 2006.

![coupe de peau anatomique. trois zones d'action niacinamide : mélanocyte basal, couche cornée, glande sébacée.](/assets/diagrams/niacinamide-mechanism.svg)

*trois zones d'action : le mélanocyte basal, la couche cornée, la glande sébacée.*

## les bénéfices prouvés

### atténuation des taches en 8 à 12 semaines

études cliniques sur peaux modérément hyperpigmentées : à 5 %, deux applications par jour, réduction visible des taches solaires et post-inflammatoires entre la 8ᵉ et la 12ᵉ semaine. effet plus modeste que la trétinoïne ou l'hydroquinone, mieux toléré sur peau sensible.

`[CITATION — verify PubMed]` hakozaki et al. 2002. bissett et al. 2004.

### renforcement de la barrière en 4 semaines

TEWL (perte d'eau transépidermique) mesurée par évaporimétrie : baisse significative dès la 4ᵉ semaine d'application à 2 %. c'est la base scientifique de l'usage *niacinamide pour préparer à la rétinoïde* documenté dans les protocoles dermatologiques.

### réduction de l'érythème et des rougeurs

effet anti-inflammatoire indirect, par inhibition de la libération de cytokines pro-inflammatoires. utile en post-procédure (laser, microneedling) pour calmer la phase inflammatoire. à valider avec ton praticien selon le protocole de ta clinique.

### effet anti-âge subtil mais documenté

à 5 %, étude sur 12 semaines : amélioration mesurée des ridules superficielles et de l'élasticité (cutométrie). ce n'est pas un substitut au rétinol, c'est un complément qui en réduit l'irritation tout en additionnant un bénéfice anti-âge propre.

`[CITATION — verify PubMed]` bissett et al., dermatol surg 2005.

## pour quel type de peau

- **peaux mixtes à grasses** avec brillances et pores dilatés : c'est l'indication reine. 5 % matin et soir.
- **peaux à imperfections** non actives : effet régulateur sans agresser. à combiner avec un BHA en alternance.
- **peaux ternes ou marquées de taches** post-inflammatoires : 5 % matin, en couche fine sous spf.
- **peaux sensibles ou rosacée légère** : commencer à 2 ou 4 % une fois par jour, augmenter progressivement. effet apaisant mesurable.
- **peaux matures** en complément du rétinol : niacinamide le matin, rétinol le soir. c'est l'association pivot du protocole anti-âge k-beauty.

### pour qui ça ne marche pas

les peaux qui flushent immédiatement (rougeur passagère liée à la libération d'histamine) : reformuler vers panthénol ou centella. quelques cas rares d'intolérance au-delà de 10 %. ce n'est pas un actif pour les acnés inflammatoires actives, qui demandent un traitement médical adapté.

## comment l'intégrer dans ta routine

**matin** · après ton toner, avant ta crème et ton spf. une noisette suffit. la niacinamide est compatible avec tout ce que tu poses ensuite.

**soir** · même placement, avant la crème. si tu utilises un rétinol, applique d'abord la niacinamide, attends 60 secondes, puis le rétinol. ou alterne soir par soir si ta peau découvre le rétinoïde.

**fréquence** · quotidienne. aucune toxicité documentée à usage chronique aux concentrations cosmétiques.

### compatibilité avec les autres actifs

| niacinamide + | compatibilité | note pratique |
|---|---|---|
| vitamine C (LAA) | ✓ | mythe d'incompatibilité fondé sur des conditions non cosmétiques. possible dans la même routine. |
| rétinol / rétinal | ✓ | association pivot anti-âge. la niacinamide réduit l'irritation rétinoïde mesurée. |
| acide hyaluronique | ✓ | synergie hydratation et barrière. combinaison standard glass skin. |
| BHA (acide salicylique) | ✓ | alterner soir par soir si la peau pique. rinçage entre les deux pour les peaux fines. |
| AHA (glycolique, lactique) | ~ | possible mais à séparer dans la journée. AHA le soir, niacinamide le matin. |
| peptides | ✓ | aucune interaction négative documentée. empilage standard. |
| cuivre peptide | ✗ | la niacinamide chélaterait le cuivre. séparer dans le temps (matin et soir distincts). |

## les sérums niacinamide recommandés

trois sélections coréennes que la niacinamide met en valeur, à des concentrations et des budgets différents. validées par notre équipe à séoul.

### cosrx · the niacinamide 15 serum

![flacon cosrx the niacinamide 15 serum, fond mint sonagi, application au compte-gouttes.](/assets/images/ingredients/niacinamide-cosrx.webp)

15 %, la concentration max documentée comme tolérable. pour pores dilatés et taches tenaces. texture aqueuse, sans parfum. 22,90 €.

### anua · niacinamide 10 + TXA 4

![flacon anua niacinamide 10 + txa 4, fond banane sonagi, modèle riant.](/assets/images/ingredients/niacinamide-anua.webp)

synergie niacinamide 10 % et acide tranexamique 4 % pour les taches résistantes. le combo dépigmentant le mieux toléré. 28,00 €.

### glow recipe · watermelon niacinamide dew drops

![flacon glow recipe watermelon niacinamide dew drops, fond rose sonagi, application sur la pommette.](/assets/images/ingredients/niacinamide-glow-recipe.webp)

4 % niacinamide en finition glow. texture huile-aqueuse. peut se mélanger au fond de teint pour un effet mool-gwang instantané. 38,00 €.

## le mot d'asma

> `[ANECDOTE — Asma personalize]`
>
> stub à compléter par asma. quelques cadres possibles à adapter :
>
> - quand tu as introduit la niacinamide à ton protocole pré-sculptra et ce que tu as observé sur ton érythème.
> - la conversation avec [formulateur coréen visité à séoul] sur le choix 5 % versus 10 %.
> - l'erreur la plus fréquente que tu vois en consultation : empiler trop d'actifs et perdre le bénéfice de la niacinamide.
> - le pivot du jour où tu as remplacé ta vitamine C matinale par un duo niacinamide + spf teinté.

## le rituel niacinamide

cinq pièces, une logique. préparer la peau, livrer l'actif, soutenir la barrière, protéger. le pack qu'on te recommande pour démarrer.

1. beauty of joseon · ginseng cleansing oil
2. anua · pha toner
3. cosrx · niacinamide 15 serum
4. laneige · water bank cream
5. beauty of joseon · relief sun spf50+

prix individuel : 112,40 €. prix rituel : 95,00 €. économie : 15 %.

`[CTA — bundle SKU: rituel-niacinamide]`

## tes questions

### niacinamide tous les jours, c'est trop ?

non. à 5 % matin et soir, l'usage quotidien est documenté comme bien toléré sur 12 semaines minimum. à 10 %, certaines peaux sensibles ressentent un flush passager. réduire à un usage quotidien unique le soir, et augmenter progressivement.

### peut-on associer niacinamide et vitamine C dans la même routine ?

oui. le mythe de l'incompatibilité repose sur une étude des années 60 conduite à des températures et concentrations non cosmétiques. les formulations modernes les associent sans perte d'efficacité documentée. tu peux les empiler ou alterner matin et soir selon ce que ta peau préfère.

### niacinamide ou rétinol contre les rides ?

les deux, à des moments différents. rétinol le soir pour stimuler le renouvellement cellulaire. niacinamide matin et soir pour soutenir la barrière et apaiser l'irritation rétinoïde. c'est l'association la plus documentée pour démarrer un protocole anti-âge.

### combien de temps avant de voir un résultat ?

régulation du sébum et apaisement : 2 à 4 semaines. atténuation des taches : 8 à 12 semaines. renforcement de la barrière mesurable au TEWL : 4 semaines. photographier ta peau toutes les 4 semaines en lumière constante reste le meilleur juge.

### niacinamide pendant la grossesse ?

considéré comme sûr selon les bases de données de tératovigilance (crat, lactmed). demande tout de même validation à ton médecin si ta grossesse est suivie. c'est un réflexe que nous recommandons pour tout actif, même bien toléré.

### 5 % ou 10 % : quelle concentration choisir ?

5 % couvre 90 % des bénéfices documentés et tolère mieux les peaux sensibles. 10 % et plus accélère légèrement la régulation séborégulatrice et l'effet sur les taches, au prix d'un risque de flush ou picotements transitoires. démarrer à 5 % et monter si la peau le supporte.

## à lire ensuite

- [glass skin · 물광](/content/techniques/fr/glass-skin.md) · pourquoi la niacinamide est l'un des trois piliers du mool-gwang.
- [routine k-beauty anti-âge](/content/routines/fr/routine-anti-age.md) · où poser la niacinamide quand tu introduis le rétinol.
- [rejuran · PDRN](/content/techniques/fr/rejuran-pdrn.md) · le post-procédure. niacinamide pour calmer l'inflammation.

---

*entry status : v0.1 draft. requires medical fact-check by `medical-fact-checker`. requires asma personalisation in `[ANECDOTE — Asma personalize]` block. all `[CITATION — verify PubMed]` markers must be replaced with verified PubMed IDs before publish per Sonagi Reference Programme rules.*
