---
id: glass-skin
name: glass skin
name_korean: 물광
alternate_names:
  - mool-gwang
  - dewy skin
  - honey skin
category: technique
korean_concepts:
  - mool-gwang
  - 7-skin-method
  - honey-skin
  - cloudless-skin
concerns:
  - hydratation
  - eclat
  - barriere
  - pores
  - grain
  - rougeurs
skin_types:
  - peau-mixte
  - peau-grasse
  - peau-normale
  - peau-sensible
  - peau-seche
personas:
  - curieuse
  - strategique
  - reguliere
related_entries:
  - niacinamide
  - acide-hyaluronique
  - ceramides
  - routine-anti-age
  - rejuran-pdrn
sources:
  - title: "[CITATION — verify PubMed] Verdier-Sévrain & Bonté, 'Skin hydration: a review on its molecular mechanisms'"
    journal: "Journal of Cosmetic Dermatology"
    year: 2007
    pubmed_id: ""
  - title: "[CITATION — verify PubMed] Egawa et al., 'In vivo estimation of stratum corneum thickness from water concentration profiles'"
    journal: "Skin Research and Technology"
    year: 2002
    pubmed_id: ""
  - title: "[CITATION — verify PubMed] Elias, 'Stratum corneum defensive functions: an integrated view'"
    journal: "Journal of Investigative Dermatology"
    year: 2005
    pubmed_id: ""
  - title: "[CITATION — verify PubMed] Rawlings & Matts, 'Stratum corneum moisturization at the molecular level'"
    journal: "Journal of Investigative Dermatology"
    year: 2005
    pubmed_id: ""
last_updated: 2026-05-09
contributors:
  - asma-bakhtar
fact_checked: false
fact_checked_by: null
medical_claims: false
human_review_required: true
content_pillar: education
featured_image: /assets/images/techniques/glass-skin-hero.webp
featured_image_alt: "portrait éditorial sur fond banane sonagi, peau mate méditerranéenne en plein mool-gwang, reflets spéculaires sur les pommettes, l'arête du nez et l'os frontal, tempe légèrement humide avec baby hairs."
diagram: /assets/diagrams/glass-skin-skin-anatomy.svg
diagram_alt: "coupe d'épiderme en cinq strates (cornée, granuleuse, épineuse, basale, derme) avec gradient d'hydratation marqué dans la couche cornée et ciment lipidique intact entre cornéocytes."
gallery:
  - path: /assets/images/techniques/glass-skin-toner.webp
    alt: "application du toner en 7-skin method, tapotements à la paume sur peau encore humide, fond mint sonagi."
  - path: /assets/images/techniques/glass-skin-essence.webp
    alt: "essence fermentée pressée entre les paumes avant pose, lumière rasante qui révèle la texture aqueuse, fond rose sonagi."
  - path: /assets/images/techniques/glass-skin-finition.webp
    alt: "finition mool-gwang sur pommette en lumière studio, reflet spéculaire net, grain de peau et pores préservés, fond banane sonagi."
references_in_routines:
  - routine-anti-age
references_in_ingredients:
  - niacinamide
  - acide-hyaluronique
  - ceramides
seoul_validated: true
sonagi_time_context: "le soir en sept étapes, le matin en quatre. le rituel s'étire entre la sortie de douche et le sleeping mask. on ralentit, on tapote, on laisse l'eau faire son travail."
---

# glass skin

le terme coréen **물광**, prononcé *mool-gwang*, se traduit littéralement par éclat d'eau. il décrit un état de peau dont la couche cornée est tellement saturée d'hydratation que sa surface devient lisse au point de réfléchir la lumière de manière spéculaire, comme une vitre humide. ce vocabulaire circule dans la cosmétique coréenne depuis le début des années 2000, bien avant que la presse occidentale ne le rebaptise *glass skin* en 2017.

ce n'est pas une finition de maquillage ni un filtre. c'est un état physiologique mesurable au cornéomètre (hydratation de la couche cornée) et à l'évaporimètre (perte d'eau transépidermique, TEWL). une peau en mool-gwang affiche un TEWL bas et un taux d'hydratation cornéen élevé. deux indicateurs d'une barrière fonctionnelle.

la promesse réelle, sans exagération : un grain affiné, des reflets nets sur les pommettes, une peau qui ne tire pas après nettoyage. la promesse fausse : une peau sans pores, sans texture. le mool-gwang préserve les pores et le grain, il les met en lumière, il ne les efface pas.

> **résumé en une phrase.** le mool-gwang est une couche cornée saturée d'eau, soutenue par un ciment lipidique intact, qui renvoie la lumière de façon spéculaire. on l'obtient en sept étapes, on le perd en 48 heures si on sur-exfolie.

## pourquoi ça marche

trois mécanismes physiologiques produisent l'éclat mool-gwang. aucun n'est cosmétique au sens superficiel. tous concernent la structure même de l'épiderme.

### 1. une couche cornée saturée d'eau

la couche cornée, les 15 à 20 µm les plus externes de l'épiderme, est composée de cornéocytes (cellules mortes kératinisées) liés par un ciment lipidique. quand ces cornéocytes contiennent **au moins 20 % d'eau**, ils gonflent légèrement, leur surface s'aplatit, et la peau passe d'une réflexion diffuse (mate) à une réflexion spéculaire (miroir). en dessous de 10 % d'eau cornée, la peau devient rugueuse et la lumière se disperse.

`[CITATION — verify PubMed]` verdier-sévrain & bonté, j cosmet dermatol 2007. physiologie de l'hydratation cutanée.

### 2. l'indice de réfraction de l'eau qui aplanit le relief

une peau hydratée a un indice de réfraction proche de celui de l'eau (1,33), ce qui réduit le contraste optique entre les microreliefs de surface et lisse visuellement la peau sans la combler. c'est le principe d'une feuille de papier mouillée qui devient translucide : l'eau remplit les irrégularités, la lumière traverse. la peau ne change pas anatomiquement, c'est sa réponse optique qui change.

`[CITATION — verify PubMed]` egawa et al., skin res technol 2002. mesure optique de la rugosité cutanée hydratée.

### 3. des lipides intercellulaires intacts

les céramides, le cholestérol et les acides gras libres forment le ciment lipidique entre cornéocytes (modèle briques et mortier décrit par michael roberts). quand ce mortier est intact, l'eau ne s'évapore pas. TEWL mesuré bas, autour de **5 à 10 g/m²/h** sur peau saine. quand il est dégradé (sur-exfoliation, savons agressifs, climatisation excessive), le TEWL grimpe à 20-30 g/m²/h, la peau perd son eau, le mool-gwang disparaît en 48 heures.

`[CITATION — verify PubMed]` elias, j invest dermatol 2005. barrière lipidique épidermique.

![coupe d'épiderme en cinq strates. gradient d'hydratation marqué dans la couche cornée, ciment lipidique entre cornéocytes.](/assets/diagrams/glass-skin-skin-anatomy.svg)

*cinq strates épidermiques. le mool-gwang dépend de l'hydratation de la couche cornée et de l'intégrité du ciment lipidique entre cornéocytes.*

## la routine qui produit le mool-gwang

sept étapes, dans cet ordre, le soir. le matin, on garde 1, 4, 6, 7. la règle non négociable : appliquer chaque couche sur peau encore humide de la précédente. c'est la signature de la méthode coréenne et la condition optique du mool-gwang.

### 1. double nettoyage huile puis mousse

une huile démaquillante émulsionnée à l'eau pour dissoudre SPF, sébum et maquillage, suivie d'un nettoyant moussant doux pour retirer la sueur et la pollution hydrosoluble. massage en mouvements circulaires, 60 secondes minimum chaque étape. rincer à l'eau tiède, jamais chaude. *type : huile démaquillante (beauty of joseon ginseng) + nettoyant pH 5,5 sans sulfates (anua heartleaf cleanser).*

### 2. toner hydratant en 7-skin method

verser le toner dans les paumes (pas sur un coton, qui absorberait 40 % du produit) et tapoter sur le visage. recommencer 3 à 7 fois en attendant 30 secondes entre chaque couche. la peau doit rester légèrement humide. c'est cette étape, originaire de corée, qui sature la couche cornée. *type : toner sans alcool, base d'eau florale ou d'extraits fermentés (anua heartleaf toner, round lab dokdo).*

### 3. essence fermentée

texture entre toner et sérum, riche en peptides issus de fermentation (galactomyces, bifida) qui renforcent la barrière et améliorent la réceptivité aux étapes suivantes. tapoter une à deux pressions dans les paumes, presser sur le visage. *type : essence fermentée >80 % de filtrat (cosrx snail mucin, missha time revolution).*

### 4. sérum acide hyaluronique

appliqué sur peau encore humide (sinon il puise l'eau de la peau, effet inverse). cibler les zones les plus déshydratées : pommettes, contour mâchoire. une à deux pressions suffisent. *type : HA multi-poids moléculaires (torriden dive-in, isntree hyaluronic acid).*

### 5. sérum niacinamide ou peptides

niacinamide à 5 % matin et soir pour la régulation barrière et l'éclat. peptides en alternative pour soutien collagène. à ce stade la peau est saturée d'eau, l'actif pénètre dans un environnement optimal. *type : sérum niacinamide 5 % (cosrx the niacinamide) ou complexe peptides (medicube collagen).*

### 6. crème occlusive légère

le rôle de la crème dans le protocole mool-gwang n'est pas d'hydrater (les couches précédentes l'ont fait) mais de *sceller*. une texture gel-crème ou émulsion légère suffit. trop riche, elle alourdit. trop fine, elle laisse fuir l'eau. *type : gel-crème ou émulsion à base d'eau, squalane ou panthénol (laneige water bank, belif aqua bomb).*

### 7. spf coréen le matin, sleeping mask le soir

le matin, un SPF coréen chimique fluide (beauty of joseon, round lab) qui ne blanchit pas et ne casse pas l'éclat. le soir, un sleeping mask gel deux à trois fois par semaine pour prolonger l'hydratation pendant les sept heures de sommeil. *type : SPF50+ PA++++ fluide, sleeping mask gel (laneige water sleeping mask).*

## les trois erreurs

### 1. empiler les actifs sans hydratation

l'erreur la plus fréquente, surtout chez les peaux qui découvrent la k-beauty via tiktok. acide glycolique le lundi, rétinol le mardi, vitamine C le mercredi, BHA le jeudi : la barrière prend la quatrième nuit, le TEWL grimpe, la peau devient inconfortable, et le mool-gwang devient impossible, quelle que soit la qualité des actifs. la hiérarchie correcte est inversée : **hydratation et barrière en fondation, actifs en surcouche**, jamais l'inverse.

### 2. sécher la peau avant d'appliquer

le mool-gwang demande une peau encore humide à chaque étape. tamponner doucement avec une serviette propre après nettoyage est correct. frotter ou attendre 5 minutes que la peau sèche complètement annule 60 % de l'efficacité du toner et du sérum HA qui suivent. la peau humide est plus perméable, le 7-skin method n'a de sens qu'à cette condition.

### 3. oublier la barrière

une couche cornée fragile ne génère pas plus d'éclat, elle laisse fuir plus d'eau. sur-exfolier en pensant *lisser pour faire briller* est l'erreur miroir de la première : on cherche le mool-gwang en démontant le ciment lipidique qui le rend possible. si ta peau pique en application de produit ou tire après nettoyage, la priorité n'est pas un nouveau sérum éclat. c'est trois semaines de réparation barrière (céramides, panthénol, centella) avant tout.

## le mot d'asma

> `[ANECDOTE — Asma personalize]`
>
> stub à compléter par asma. quelques cadres possibles à adapter :
>
> - ton premier voyage à séoul et la première fois que tu as compris la différence concrète entre *glowy* à l'occidentale et le mool-gwang en consultation chez une esthéticienne coréenne.
> - le matin où ton dermatologue t'a expliqué le 7-skin method et pourquoi appliquer le toner avec un coton est une perte sèche de produit.
> - l'erreur que tu vois le plus souvent en consultation : des clientes qui empilent les actifs et n'ont jamais mis un sleeping mask coréen.
> - la cliente type (peau mate méditerranéenne ou maghrébine) qui pense que le mool-gwang ne marche pas sur sa peau, et la transformation en 8 semaines avec une routine épurée.

## le rituel glass skin

six pièces, une logique. nettoyer sans décaper, saturer la couche cornée, sceller avec un occlusif léger, protéger. le pack que nos clientes utilisent pour basculer en mool-gwang en 6 à 8 semaines.

1. beauty of joseon · ginseng cleansing oil
2. anua · heartleaf toner
3. cosrx · snail mucin essence
4. torriden · dive-in serum
5. laneige · water bank cream
6. beauty of joseon · relief sun spf50+

prix individuel : 138,40 €. prix rituel : 118,00 €. économie : 15 %.

`[CTA — bundle SKU: rituel-glass-skin]`

## tes questions

### combien de temps pour obtenir le mool-gwang ?

premiers signes visibles à 2 semaines : reflet plus net sur les pommettes, grain affiné. effet plein à 6 à 8 semaines, le temps que la couche cornée se reconstruise complètement (le cycle de renouvellement épidermique fait 28 jours, il en faut deux pour stabiliser une barrière fragilisée). photographier ta peau toutes les deux semaines en lumière constante reste le meilleur juge.

### glass skin et peau grasse, c'est compatible ?

oui, et c'est même une indication. la peau grasse qui brille est rarement une peau hydratée, c'est une peau déshydratée qui surproduit du sébum pour compenser. le mool-gwang appliqué à une peau mixte à grasse calme souvent la production sébacée en 4 à 6 semaines. choisir des textures gel-aqueuses et une crème occlusive légère, pas une crème riche.

### peut-on faire le mool-gwang sans 10 produits ?

oui. les 7 étapes sont la version complète. la version épurée tient en 4 : nettoyant doux, toner hydratant, sérum acide hyaluronique, crème et SPF le matin. ce qui compte n'est pas le nombre de couches mais la séquence : nettoyer sans décaper, hydrater en couches fines sur peau humide, sceller avec un occlusif.

### la peau noire ou métisse a-t-elle les mêmes besoins ?

oui pour la logique d'hydratation et de barrière, qui est universelle. les peaux à mélanine élevée ont en moyenne une couche cornée plus compacte et un TEWL légèrement plus bas, ce qui les rend plus réceptives au mool-gwang. vigilance sur les actifs acides (AHA fortes doses) qui peuvent déclencher des taches post-inflammatoires : préférer la niacinamide et l'acide tranexamique pour l'éclat.

### mool-gwang, honey skin, cloudless skin : quelles différences ?

trois nuances du même axe. mool-gwang : éclat humide spéculaire, comme une couche d'eau. honey skin : finition plus tiède, dorée, légèrement plus mate, popularisée par park min-young. cloudless skin : peau sans imperfection visible, grain uniforme, finition satinée. le mool-gwang est la base. honey et cloudless sont des variations stylistiques au-dessus.

### faut-il un humidificateur dans la chambre ?

utile en hiver dans les appartements chauffés où l'humidité descend sous 30 %. cible : 40 à 55 % d'humidité relative. à ce niveau la peau perd moins d'eau pendant la nuit, le sleeping mask agit mieux. un hygromètre à 12 € suffit pour mesurer. pas besoin d'humidificateur si ta chambre est déjà au-dessus de 40 %.

### le mool-gwang tient-il sous le maquillage ?

oui, à condition que la base soit posée sur peau encore légèrement humide et que le fond de teint soit fluide (cushion coréen, base aqueuse). une poudre matifiante généreuse annule l'effet. pour fixer sans casser : brume hydratante en finition plutôt que poudre.

## à lire ensuite

- [niacinamide · 나이아신아마이드](/content/ingredients/fr/niacinamide.md) · l'actif qui sature la barrière et soutient l'éclat. pilier du protocole mool-gwang.
- [routine k-beauty anti-âge](/content/routines/fr/routine-anti-age.md) · comment empiler rétinol et glass skin sans perdre la barrière.
- [rejuran · PDRN](/content/techniques/fr/rejuran-pdrn.md) · le geste clinique qui complète le mool-gwang sur peaux matures.

---

*entry status : v0.1 draft. requires medical fact-check by `medical-fact-checker`. requires asma personalisation in `[ANECDOTE — Asma personalize]` block. all `[CITATION — verify PubMed]` markers must be replaced with verified PubMed IDs before publish per Sonagi Reference Programme rules.*
