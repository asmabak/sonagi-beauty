---
id: rejuran-pdrn
name: rejuran (PDRN)
name_korean: 리쥬란
alternate_names:
  - polynucléotides
  - PDRN
  - polydeoxyribonucleotide
  - salmon DNA injection
category: technique
procedure_type: percutaneous_injection
injection_depth_mm: 0.5-1
indications:
  - photo-vieillissement
  - atrophie-dermique-periorbitaire
  - cicatrices-acne-legeres
  - recuperation-post-laser
  - preparation-pre-sculptra
contraindications:
  - pregnancy
  - breastfeeding
  - autoimmune-disease
  - anticoagulants
  - active-skin-infection
  - salmon-allergy
  - keloid-history
  - minors
concerns:
  - rides
  - elasticite
  - cernes-creuses
  - cicatrices-acne
  - eclat
korean_concepts:
  - glass-skin
  - dongan
skin_types:
  - peau-mature
  - peau-mixte
  - peau-normale
  - peau-seche
personas:
  - strategique
  - reguliere
related_entries:
  - niacinamide
  - glass-skin
  - routine-anti-age
  - ceramides
  - panthenol
regulatory:
  eu_status: CE classe III (dispositif médical injectable)
  france_status: acte médical réservé aux médecins (ANSM, prescription requise)
  korea_status: MFDS approuvé 2014 (PharmaResearch, fabricant officiel)
  fda_status: not approved in US (2026)
  pregnancy_safe: false
  pregnancy_source: precaution-injectable-no-teratovigilance-data
manufacturer: PharmaResearch (Corée du Sud)
sources:
  - title: "[CITATION — verify PubMed] Kim et al., 'Polydeoxyribonucleotide injection for skin rejuvenation'"
    journal: "Aesthetic Surgery Journal"
    year: 2017
    pubmed_id: ""
  - title: "[CITATION — verify PubMed] Squadrito et al., 'Pharmacological activity and clinical use of PDRN'"
    journal: "Frontiers in Pharmacology"
    year: 2017
    pubmed_id: ""
  - title: "[CITATION — verify PubMed] Lee et al., 'Clinical efficacy of polynucleotide filler in skin texture'"
    journal: "Dermatologic Surgery"
    year: 2018
    pubmed_id: ""
last_updated: 2026-05-15
contributors:
  - asma-bakhtar
fact_checked: false
fact_checked_by: null
medical_claims: true
human_review_required: true
content_pillar: education
featured_image: /assets/images/techniques/rejuran-pdrn-hero.webp
featured_image_alt: "portrait éditorial post-soin, peau brune mature, instant de récupération après séance, fond pêche clinique sonagi, texture cutanée préservée (micropapules visibles atténuées, hâle naturel), aucune aiguille à l'écran."
diagram: /assets/diagrams/dermal-injection-depth.svg
diagram_alt: "coupe anatomique de la peau en perspective 3 quart, marquages des couches : épiderme, derme papillaire à 0,5-1 mm, derme réticulaire, hypoderme. dépôt PDRN signalé au niveau du derme papillaire, comparaison visuelle avec les profondeurs filler et mésothérapie."
gallery:
  - path: /assets/diagrams/rejuran-timeline.svg
    alt: "frise du protocole : quatre séances espacées de deux semaines, puis maintenance à quatre à six mois. couleurs sonagi navy et pêche."
references_in_routines:
  - routine-anti-age
references_in_ingredients:
  - niacinamide
  - panthenol
  - ceramides
seoul_validated: true
sonagi_time_context: "soin médical clinique, hors rituel quotidien. l'entretien à la maison s'intègre dans le rituel sonagi time du soir, avec accent barrière et apaisement les 7 à 14 jours qui suivent la séance."
---

# rejuran (PDRN)

le rejuran est le nom commercial coréen d'une famille d'injections intradermiques de PDRN (polydeoxyribonucleotide). ce sont des fragments d'ADN extraits et purifiés à partir de gonades de saumon, fragmentés à un poids moléculaire compris entre 50 et 1 500 kDa, puis stérilisés. ce ne sont ni des cellules vivantes, ni de l'acide hyaluronique, ni un comblement volumique. c'est un signal biologique de réparation.

approuvé par la MFDS coréenne (ministry of food and drug safety) en 2014, marqué CE classe III en europe comme dispositif médical injectable. le PDRN cosmétique n'est pas approuvé par la FDA américaine en 2026, d'où l'absence du rejuran sur le marché US officiel et la profusion de versions importées non régulées. en france, c'est un acte médical réservé aux médecins, encadré par l'ANSM.

> **résumé en une phrase.** le rejuran injecte un signal de réparation dérivé d'ADN de saumon dans le derme papillaire. il densifie sans donner de volume, en 3 à 4 séances espacées de 2 semaines.

## la science

trois mécanismes documentés, tous mesurés sur fibroblastes en culture et confirmés par biopsie clinique.

### 1. activation des récepteurs A2A des fibroblastes

le PDRN se lie aux récepteurs adénosine A2A présents à la surface des fibroblastes dermiques. cette liaison déclenche une cascade intracellulaire qui stimule la synthèse de collagène de type I et III, l'activité des fibroblastes et la migration cellulaire vers les zones lésées. c'est le même récepteur que celui sollicité par la cicatrisation post-traumatique naturelle. le rejuran imite un signal de réparation que le corps reconnaît.

`[CITATION — verify PubMed]` kim et al., aesthet surg j 2017. étude clinique coréenne pivot. à vérifier avant publication.

### 2. voie de la « salvage pathway » nucléotidique

au-delà des récepteurs A2A, les fragments d'ADN libèrent localement des nucléotides et nucléosides qui servent de substrats à la synthèse d'ADN et d'ARN par les cellules voisines. c'est l'effet documenté de salvage pathway, mécanisme proposé pour expliquer la densification dermique mesurée à 8 semaines.

`[CITATION — verify PubMed]` squadrito et al., front pharmacol 2017. revue mécanistique du PDRN.

### 3. demi-vie courte, effet downstream long

le PDRN injecté est dégradé par les nucléases endogènes en quelques jours : 72 à 96 heures pour la majorité de la dose. mais l'effet biologique en aval (collagéogenèse, néovascularisation, restructuration de la matrice extracellulaire) court sur **4 à 8 semaines**. c'est cette dissociation entre la durée de vie du produit et la durée de l'effet qui explique pourquoi le protocole se construit en plusieurs séances espacées. on relance le signal avant que le précédent ne s'éteigne.

`[CITATION — verify PubMed]` lee et al., dermatol surg 2018.

![coupe anatomique de la peau. profondeur d'injection PDRN dans le derme papillaire à 0,5 à 1 mm. comparaison avec mésothérapie (plus superficielle) et filler (plus profond).](/assets/diagrams/dermal-injection-depth.svg)

*le PDRN se dépose dans le derme papillaire, à 0,5 à 1 mm de la surface. plus profond que la mésothérapie, plus superficiel qu'un filler.*

## le protocole

protocole standard validé par les cliniques de séoul et repris par la majorité des médecins esthétiques français.

### le schéma initial

**3 à 4 séances**, espacées de **2 semaines** chacune. une séance de **maintenance tous les 4 à 6 mois** pour entretenir le résultat. certains praticiens proposent un schéma allégé en 2 séances pour les peaux jeunes (moins de 35 ans) avec atteinte modérée.

### la technique d'injection

aiguille **33G** (très fine, 0,2 mm de diamètre) ou pistolet d'injection automatique pour répartir les micropapules régulièrement. profondeur : **0,5 à 1 mm** dans le derme papillaire. volume injecté : environ **1 ml par séance** répartie en 80 à 120 micropapules sur l'ensemble du visage. une crème anesthésiante est posée 30 à 45 minutes avant la séance.

### les soins post-immédiats

- **0 à 24 h** : éviter chaleur (sauna, hammam, sport intense, bain chaud). pas de maquillage 12 h. compresses froides si rougeurs marquées.
- **24 h à 7 jours** : hydratation barrière intense (centella, panthénol, céramides). pas d'exfoliant, pas de rétinoïde, pas d'AHA ou de BHA. SPF50 obligatoire.
- **7 à 14 jours** : reprise progressive de la routine habituelle, à l'exception des actifs agressifs jusqu'à la séance suivante.

![frise du protocole : quatre séances en six semaines, maintenance à quatre à six mois.](/assets/diagrams/rejuran-timeline.svg)

*quatre séances en six semaines, puis une maintenance tous les quatre à six mois.*

## pour qui c'est indiqué

- **peaux abîmées par UV chronique** : texture rugueuse, perte d'éclat, premières ridules superficielles. c'est l'indication la plus courante après 35 ans.
- **cicatrices d'acné légères à modérées** : cicatrices atrophiques superficielles (boxcar peu profondes, rolling). effet documenté sur la régénération du derme.
- **atrophie dermique péri-orbitaire** : paupières basses fines et froissées, cernes creusés. zone où le PDRN excelle car il densifie sans ajouter de volume.
- **préparation pré-sculptra ou pré-botox** : densifier le derme avant un acte stimulant le collagène en profondeur ou paralysant musculaire. pratique standard à séoul.
- **récupération post-laser fractionné** : accélère la cicatrisation et améliore la qualité finale du remodelage. protocole combo fraxel + rejuran de plus en plus prescrit.
- **peaux post-grossesse ou post-amaigrissement rapide** : derme distendu et déshydraté, pas encore candidat aux fillers volumiques.

## pour qui c'est contre-indiqué

liste non exhaustive, à confronter à ton médecin avant toute décision.

- **grossesse et allaitement** : pas de données de tératovigilance suffisantes. aucun produit injectable cosmétique n'est validé pendant ces périodes.
- **maladies auto-immunes actives** : lupus érythémateux, sclérodermie, polyarthrite rhumatoïde en poussée. le PDRN module la réponse immunitaire locale, à éviter en contexte d'auto-immunité non stabilisée.
- **anticoagulants oraux ou anti-agrégants plaquettaires** : risque hémorragique majoré (bleus étendus, hématomes). à évaluer avec le médecin prescripteur. jamais d'arrêt en autonomie.
- **allergie connue au saumon ou aux fruits de mer** : contre-indication absolue. le PDRN, malgré la purification, dérive d'une protéine d'origine.
- **infection cutanée locale active** : herpès labial en poussée, acné inflammatoire sévère, eczéma suintant, impétigo. reporter la séance jusqu'à résolution complète.
- **antécédents de cicatrisation chéloïde** : à discuter au cas par cas avec un dermatologue.
- **mineurs** : le PDRN n'est pas indiqué avant 18 ans, peau encore en remodelage spontané.

## coût et où le faire

### fourchette de prix

**en france** · 280 à 450 € par séance dans les cliniques esthétiques agréées de paris, lyon et bordeaux. le protocole complet (3 à 4 séances) revient à **900 à 1 800 €**. la maintenance annuelle ajoute 280 à 450 €.

**à séoul** · 200 000 à 350 000 KRW par séance, soit environ **140 à 240 €**. protocole complet à 600 à 1 000 €. le différentiel france/corée s'explique par le coût de la consultation médicale, la TVA et les marges des cliniques européennes, pas par la qualité du produit, identique.

### comment choisir une clinique

- **praticien médecin uniquement** : médecin esthétique, dermatologue ou chirurgien plasticien. jamais une esthéticienne, jamais une infirmière en autonomie. c'est un acte médical en france.
- **produit en flacon scellé** : fabriqué par PharmaResearch (corée du sud), seul fabricant officiel du rejuran. demander à voir le flacon avant ouverture, vérifier le sceau et la mention « rejuran » avec le numéro de lot.
- **marquage CE et numéro de lot tracés** : le médecin doit pouvoir te montrer l'autorisation CE classe III et noter le numéro de lot dans ton dossier. pas de produit reconditionné ou décanté d'un grand flacon.
- **consultation préalable obligatoire** : une clinique sérieuse impose une consultation séparée avant la première injection. refuser les protocoles consultation et injection le même jour, qui escamotent l'évaluation médicale.

sonagi ne recommande pas de clinique spécifique. ton dermatologue ou médecin esthétique formé en injection PDRN est le bon point de départ.

## le mot d'asma

> `[ANECDOTE — Asma personalize]`
>
> stub à compléter par asma. extra important sur cette page : le rejuran fait partie de son protocole personnel. quelques cadres possibles à adapter, ne pas inventer.
>
> - le contexte de ta première séance rejuran : l'occasion, la clinique (séoul ou paris ?), ton âge à ce moment-là, ce que tu cherchais à corriger.
> - la sensation pendant l'injection : douleur réelle, durée, sensation post-immédiate (chaleur, picotement, micropapules visibles).
> - les 14 premiers jours et les bleus : la réalité brute, pas la version instagram. ce que tu as caché et ce que tu as assumé en public.
> - la différence visible à 8 semaines : ce que tu as photographié, ce que les autres ont remarqué (ou pas), ce qui a changé que personne ne voit.
> - pourquoi tu fais rejuran avant sculptra et pas l'inverse : la logique du protocole, ce qu'on t'a expliqué à séoul, et pourquoi tu maintiens cet ordre malgré les médecins français qui proposent parfois l'inverse.
> - ce que tu ferais différemment si tu recommençais : timing, clinique, préparation, soins post.

## l'entretien post-procédure

quatre semaines après une séance, la peau a besoin de soutien barrière, d'hydratation profonde et d'un anti-inflammatoire doux. ni rétinol, ni acides agressifs. la niacinamide trouve ici sa place : effet anti-inflammatoire indirect documenté par inhibition de la libération de cytokines pro-inflammatoires, utile en post-procédure pour calmer la phase inflammatoire. le panthénol soutient la cicatrisation. les céramides reconstituent le ciment lipidique fragilisé par les micro-injections.

à valider avec ton praticien selon le protocole de ta clinique. certaines équipes coréennes prescrivent un protocole barrière strict pendant les 14 jours qui encadrent chaque séance, d'autres autorisent une reprise plus précoce.

## le rituel post-rejuran

cinq pièces, une logique : apaiser, hydrater, protéger. le pack qu'on te recommande pour soutenir la peau pendant tout le protocole.

1. anua · heartleaf 77 soothing toner
2. beauty of joseon · centella asiatica calming serum
3. torriden · dive-in serum (acide hyaluronique 5D)
4. laneige · water bank cream
5. beauty of joseon · relief sun SPF50+

prix individuel : 96,50 €. prix rituel : 82,00 €. économie : 15 %.

`[CTA — bundle SKU: rituel-post-rejuran]`

## tes questions

### combien ça fait mal ?

une crème anesthésiante est posée 30 à 45 minutes avant la séance. pendant l'injection, la sensation reste piquante mais brève. chaque micropapule dure moins d'une seconde. la douleur est plus marquée sur les zones fines (paupières basses, contour bouche) que sur les joues. échelle moyenne rapportée par les patientes : 3 à 5 sur 10. plus inconfortable qu'un facial, beaucoup moins qu'un laser fractionné.

### combien de temps de récupération ?

les micropapules visibles s'estompent en 4 à 12 heures. rougeurs : 24 à 48 heures. bleus possibles sur 5 à 10 jours selon la fragilité capillaire et la zone, surtout autour des yeux. aucun arrêt social pour les peaux peu réactives. prévoir 48 heures d'invisibilité confortable pour les peaux fines, ou si tu fais le contour des yeux.

### quand voit-on les premiers résultats ?

hydratation et confort cutané : dès la 2ᵉ semaine. la peau « boit » différemment. densification du derme et amélioration du grain : 6 à 8 semaines après la 1ʳᵉ séance. effet pleinement visible après le protocole complet de 3 à 4 séances espacées de 2 semaines, soit 3 à 4 mois après le début. photographier en lumière constante toutes les 4 semaines reste le juge le plus fiable.

### combien de temps dure l'effet ?

une fois le protocole initial complété, l'effet se maintient 6 à 9 mois selon l'âge, l'exposition UV, le tabac et la qualité du sommeil. une séance de maintenance tous les 4 à 6 mois est le rythme recommandé par la majorité des praticiens coréens. sans maintenance, le derme retrouve son état initial en 9 à 12 mois.

### rejuran ou sculptra : par où commencer ?

rejuran d'abord. le PDRN répare et densifie le derme, il prépare le terrain. le sculptra (acide poly-L-lactique) ensuite stimule la synthèse de collagène en volume, sur un derme déjà sain. faire l'inverse, c'est construire sur un sol fragile. c'est la séquence enseignée à séoul et celle que recommandent la majorité des praticiens formés en corée.

### peut-on combiner rejuran et rétinol à la maison ?

pas dans les 7 jours qui encadrent une séance. arrêter le rétinoïde 5 jours avant et 7 jours après, le temps que la peau cicatrise les points d'injection. au-delà de cette fenêtre, l'association est non seulement compatible mais recommandée. niacinamide et rétinol soutiennent l'effet PDRN sur la durée en stimulant le renouvellement épidermique en parallèle de la régénération dermique.

### est-ce contre-indiqué pendant la grossesse ?

oui. la grossesse et l'allaitement sont des contre-indications relatives à toute injection esthétique, en l'absence de données de tératovigilance suffisantes. reporter le protocole. pour les soins topiques compatibles pendant la grossesse, voir l'entrée niacinamide.

### combien de séances faut-il vraiment ?

3 à 4 séances initiales, espacées de 2 semaines. en deçà de 3 séances, l'effet downstream cumulatif est incomplet et le résultat à 3 mois reste partiel. au-delà de 4 séances rapprochées, aucun bénéfice supplémentaire documenté. la maintenance se discute ensuite tous les 4 à 6 mois selon le rendu.

## à lire ensuite

- [niacinamide · 나이아신아마이드](/content/ingredients/fr/niacinamide.md) · l'actif barrière à intégrer en post-procédure pour calmer l'inflammation.
- [routine k-beauty anti-âge](/content/routines/fr/routine-anti-age.md) · où intégrer le rejuran dans un protocole quotidien cohérent.
- [glass skin · 물광](/content/techniques/fr/glass-skin.md) · l'objectif esthétique que le PDRN soutient sur la durée.

---

**avertissement médical**

cet article est éducatif. il ne remplace pas une consultation avec un dermatologue ou un médecin esthétique. toute décision concernant une procédure injectable doit se prendre avec un praticien qualifié, après évaluation individuelle. les résultats varient selon l'individu, l'âge, l'état du derme et l'observance des soins post-procédure. le PDRN est un dispositif médical de classe III en europe, son administration relève d'un acte médical encadré par l'ANSM en france.

---

*entry status : v0.1 draft. requires medical fact-check by `medical-fact-checker` (procédure injectable, vigilance accrue). requires asma personalisation in `[ANECDOTE — Asma personalize]` block (extra important : protocole personnel d'asma). all `[CITATION — verify PubMed]` markers must be replaced with verified PubMed IDs before publish per Sonagi Reference Programme rules. contre-indications doivent être relues par médecin avant publication.*
