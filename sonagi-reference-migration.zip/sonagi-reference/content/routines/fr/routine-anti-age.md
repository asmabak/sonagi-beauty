---
id: routine-anti-age
name: routine k-beauty anti-âge
name_korean: 안티에이징 루틴
alternate_names:
  - protocole anti-âge coréen
  - routine anti-âge k-beauty
category: routine
target_age_range: 30+
target_concerns:
  - premieres-rides
  - eclat
  - fermete
  - taches
  - anti-age
korean_concepts:
  - glass-skin
  - mool-gwang
skin_types:
  - peau-mixte
  - peau-normale
  - peau-seche
  - peau-sensible
personas:
  - strategique
  - reguliere
morning_steps:
  - nettoyant-doux
  - toner-hydratant
  - serum-vitamine-c
  - creme-peptides-niacinamide
  - spf-50
evening_steps:
  - demaquillant-huileux
  - nettoyant-doux
  - toner-hydratant
  - essence-fermentee
  - serum-retinal
  - serum-peptides-bakuchiol
  - creme-riche-sleeping-mask
weekly_actives:
  - masque-pha
  - masque-tissu-hydratant
  - traitement-cabinet-pdrn
introduction_calendar_weeks: 12
expected_timeline_visible_results: "8-12 semaines pour ridules ; 12-16 semaines pour fermeté"
related_entries:
  - niacinamide
  - retinal
  - peptides
  - vitamine-c
  - ceramides
  - glass-skin
  - rejuran-pdrn
regulatory:
  eu_status: routine cosmétique standard
  france_status: routine cosmétique standard
  korea_status: protocole k-beauty 7 étapes
  pregnancy_safe: false
  pregnancy_source: "rétinoïdes contre-indiqués. substituer par bakuchiol et peptides."
sources:
  - title: "[CITATION — verify PubMed] Mukherjee et al., 'Retinoids in the treatment of skin aging: an overview of clinical efficacy and safety'"
    journal: "Clinical Interventions in Aging"
    year: 2006
    pubmed_id: ""
  - title: "[CITATION — verify PubMed] Kligman et al., 'Topical tretinoin for photoaged skin'"
    journal: "Journal of the American Academy of Dermatology"
    year: 1986
    pubmed_id: ""
  - title: "[CITATION — verify PubMed] Bissett et al., 'Niacinamide: a B vitamin that improves aging facial skin appearance'"
    journal: "Dermatologic Surgery"
    year: 2005
    pubmed_id: ""
  - title: "[CITATION — verify PubMed] Dhaliwal et al., 'Prospective, randomized, double-blind assessment of topical bakuchiol and retinol'"
    journal: "British Journal of Dermatology"
    year: 2019
    pubmed_id: ""
  - title: "[CITATION — verify PubMed] Green et al., 'Polynucleotide injection (PDRN) for skin rejuvenation: clinical outcomes'"
    journal: "Journal of Cosmetic Dermatology"
    year: 2020
    pubmed_id: ""
last_updated: 2026-05-09
contributors:
  - asma-bakhtar
fact_checked: false
fact_checked_by: null
medical_claims: false
human_review_required: true
content_pillar: education
featured_image: /assets/images/routines/routine-anti-age-hero.webp
featured_image_alt: "portrait éditorial d'une femme 50+ à la peau brune profonde, lumière naturelle douce, peau soutenue et lumineuse sans maquillage marqué, fond pêche saturé sonagi, texture cutanée préservée."
diagram: /assets/diagrams/routine-anti-age-morning.svg
diagram_alt: "timeline visuelle des 5 étapes du rituel matin numérotées de 1 à 5, palette pêche sonagi, durée totale 4 minutes, icônes des produits et bulles de texte pour chaque geste."
gallery:
  - path: /assets/diagrams/routine-anti-age-evening.svg
    alt: "timeline visuelle des 7 étapes du rituel soir numérotées de 1 à 7, palette pêche sonagi, durée totale 12 minutes, icônes des produits et bulles de texte pour chaque geste."
  - path: /assets/diagrams/routine-anti-age-12-week-calendar.svg
    alt: "calendrier sur 12 semaines d'introduction progressive des actifs, grille en lignes horizontales par actif (nettoyage, vitamine c, niacinamide, rétinal, peptides, masques), palette pêche sonagi."
references_in_routines: []
references_in_techniques:
  - glass-skin
  - rejuran-pdrn
seoul_validated: true
sonagi_time_context: "le rituel matin tient en 4 minutes, le rituel soir en 12 minutes. la cascade k-beauty privilégie sept gestes courts à une étape musclée, dans la logique sonagi time : on ralentit, on ne se presse pas."
---

# routine k-beauty anti-âge

cette routine s'adresse aux peaux à partir de 35 ans, au moment où apparaissent les premiers signaux mesurables : ridules superficielles autour des yeux et du sillon nasogénien, perte d'élasticité cutométrique, taches solaires sur les pommettes et les mains. avant 35 ans, l'investissement le plus rentable reste le spf quotidien et l'hydratation barrière. pas la peine d'empiler les actifs.

le calendrier de résultat est honnête. 3 à 6 mois pour les premiers signaux mesurables (TEWL en baisse, élasticité en hausse, taches qui s'atténuent), 12 mois pour la transformation visible que tu vois dans le miroir sans avoir à comparer une photo. c'est un investissement biologique long, pas un sprint cosmétique.

la différence k-beauty tient en une phrase : layering doux et actifs en cascade plutôt qu'une bombe rétinoïque unique. on préfère sept étapes courtes à une étape musclée. le résultat : une peau qui tolère l'anti-âge sur la durée. et qui donne ce rendu glass-skin qu'on associe au protocole coréen.

> **résumé en une phrase.** matin pour protéger (vitamine C, niacinamide, spf 50), soir pour traiter (rétinal, peptides, occlusion), 12 semaines pour intégrer la cascade complète sans saturer la peau.

## le rituel matin

cinq étapes. quatre minutes. le matin, on protège. on ne traite pas. la logique : barrière préservée, antioxydant en surface, spf par-dessus.

### 1. nettoyant doux

gel ou mousse à pH ~5,5. préserve la barrière, ne décape pas. pas d'eau chaude, juste tiède. au réveil, la peau a juste besoin d'un rinçage tendre, pas d'un décapage. les peaux 35+ tolèrent de plus en plus mal les nettoyants alcalins. c'est le premier point où on perd la barrière sans s'en rendre compte.

picks · cosrx low pH good morning cleanser · anua heartleaf quercetinol cleanser.

### 2. toner hydratant

sans alcool, type 7-skin method (sept couches légères tapotées à la main). recharge l'eau cellulaire avant les actifs. cette étape est le pivot k-beauty. elle prépare la peau à recevoir tout ce qui suit, et améliore la pénétration mesurée des sérums.

picks · anua heartleaf 77 soothing toner · numbuzin no.3 skin softening serum.

### 3. sérum vitamine C

10 à 15 % de LAA stable ou dérivé (ascorbyl glucoside). antioxydant qui multiplie par deux la photoprotection cellulaire de ton spf. à appliquer en couche fine sur peau légèrement humide du toner.

`[CITATION — verify PubMed]` études cliniques sur la synergie vitamine c + spf, à vérifier avant publication.

picks · beauty of joseon glow serum · skin1004 madagascar centella ampoule + vitamin c.

### 4. crème peptides + niacinamide

soutien barrière (niacinamide à 5 %) plus signal de synthèse collagénique (peptides de type matrixyl ou cuivre). l'association la mieux documentée pour les peaux 35+ qui veulent maintenir l'élasticité sans sur-stimuler.

picks · cosrx advanced snail 92 all in one cream · mixsoon centella asiatica cream.

### 5. spf 50 PA++++

non négociable. le seul anti-âge dont l'efficacité est démontrée à 100 % sur la prévention du photovieillissement. texture coréenne fluide pour que tu l'appliques tous les jours sans effort. réappliquer toutes les 2 heures en exposition directe.

`[CITATION — verify PubMed]` hughes et al., the effect of sunscreen on skin aging, australia study 2013. à vérifier.

picks · beauty of joseon relief sun rice + probiotics · round lab birch juice moisturizing sunscreen.

![timeline visuelle des 5 étapes du rituel matin numérotées de 1 à 5, palette pêche sonagi, durée totale 4 minutes.](/assets/diagrams/routine-anti-age-morning.svg)

*le rituel matin en 4 minutes : nettoyer, hydrater, antioxyder, soutenir, protéger.*

## le rituel soir

sept étapes. une douzaine de minutes. le soir, on traite. réparation, renouvellement cellulaire, recharge profonde. c'est le moment où le travail anti-âge se fait.

### 1. démaquillant huileux

masser à sec sur peau sèche pour dissoudre spf, sébum et particules de pollution. émulsionner à l'eau tiède puis rincer. l'huile dissout l'huile : c'est la chimie de base du double nettoyage coréen.

picks · beauty of joseon ginseng cleansing oil · banila co clean it zero.

### 2. nettoyant doux

finit le travail du démaquillant. c'est ça, le double nettoyage coréen. deux passes douces plutôt qu'une seule agressive. la peau ressort propre, pas tiraillée.

picks · cosrx low pH good morning cleanser · anua heartleaf quercetinol cleanser.

### 3. toner hydratant

recharge après le rinçage. tapoter, ne pas frotter. la peau du soir est plus réceptive : moins de gestes, plus de présence.

picks · anua heartleaf 77 soothing toner.

### 4. essence fermentée

préparation enzymatique qui prépare la peau à recevoir les actifs suivants. c'est l'étape la plus k-beauty du protocole. type galactomyces ou pitera, deux familles fermentaires aux profils documentés.

`[CITATION — verify PubMed]` études cliniques sur galactomyces et amélioration de la rugosité cutanée. à vérifier.

picks · cosrx galactomyces 95 essence · sk-ii facial treatment essence (pitera).

### 5. sérum rétinal ou rétinol

2 à 4 soirs par semaine au début, montée progressive sur 8 semaines. renouvellement cellulaire et stimulation collagène. le rétinal (rétinaldéhyde) est mieux toléré que le rétinol à efficacité comparable, parce qu'il est une étape métabolique plus proche de l'acide rétinoïque actif.

`[CITATION — verify PubMed]` mukherjee et al., retinoids in skin aging, clin interv aging 2006. à vérifier.

picks · a.true retinal · medicube collagen retinal night cream.

### 6. sérum peptides ou bakuchiol

en alternance avec le rétinal sur les soirs sans. soutient le signal collagène sans irriter. utile aussi en grossesse comme alternative complète au rétinoïde. le bakuchiol présente une efficacité comparable au rétinol sur 12 semaines, avec une tolérance significativement supérieure.

`[CITATION — verify PubMed]` dhaliwal et al., bakuchiol vs retinol, br j dermatol 2019. à vérifier.

picks · medicube collagen night wrapping mask · the inkey list bakuchiol moisturizer.

### 7. crème riche ou sleeping mask

couche occlusive finale. renforce la barrière et retient l'eau pendant les huit heures de sommeil. le moment où la peau régénère le plus. la texture sleeping mask permet une occlusion plus généreuse sans étouffer.

picks · laneige water sleeping mask · beauty of joseon dynasty cream.

![timeline visuelle des 7 étapes du rituel soir numérotées de 1 à 7, palette pêche sonagi, durée totale 12 minutes.](/assets/diagrams/routine-anti-age-evening.svg)

*le rituel soir en 12 minutes : nettoyer deux fois, recharger, préparer, traiter, soutenir, sceller.*

## les actifs hebdomadaires

trois rituels qui s'ajoutent à la routine matin-soir, à des fréquences différentes. ils ne remplacent rien, ils amplifient.

### masque exfoliant PHA

1 fois par semaine. les PHA (gluconolactone, lactobionique) exfolient les cornéocytes morts sans agresser comme les AHA classiques. renouvellement de surface, pénétration accrue des actifs suivants. à poser le soir, jamais le même soir que le rétinal.

`[CITATION — verify PubMed]` étude sur la tolérance comparative PHA vs AHA, à vérifier avant publication.

picks · cosrx pha moisture renewal power cream · neogen bio-peel gauze peeling pha.

### masque hydratant en tissu

2 à 3 fois par semaine. recharge intensive en sérum (acide hyaluronique, centella, peptides). 15 à 20 minutes maximum. au-delà, le tissu re-pompe l'eau de la peau au lieu de la lui donner.

picks · mediheal teatree care solution · numbuzin no.5 collagen wrap mask.

### traitement en cabinet (PDRN)

tous les 4 à 6 mois. le levier qui démultiplie ta routine topique : rejuran (PDRN) en série de trois injections espacées d'un mois pour la matrice dermique, ou microneedling RF pour le remodelage en profondeur.

`[CITATION — verify PubMed]` green et al., PDRN for skin rejuvenation, j cosmet dermatol 2020. à vérifier.

à valider avec ton praticien selon le protocole de ta clinique.

## le calendrier d'introduction

ne pas tout introduire en même temps. c'est l'erreur la plus fréquente. la peau sature, irrite, et tu abandonnes au bout de trois semaines. voici le rythme qu'on recommande sur 12 semaines.

### semaines 1-2 · poser la base

nettoyage doux matin et soir, toner hydratant, crème simple, spf 50 quotidien. c'est tout. la peau s'habitue à un rythme régulier. cette phase paraît minimaliste : c'est le but. on reconstruit la barrière avant d'ajouter quoi que ce soit.

### semaines 3-4 · introduire la vitamine C

ajouter la vitamine c le matin, après le toner. démarrer à 10 % si peau sensible, 15 % sinon. observer la tolérance pendant deux semaines avant de passer à l'étape suivante.

### semaines 5-6 · ajouter la niacinamide

ajouter la niacinamide le soir, après le toner. à 5 % pour démarrer, 10 % au bout de deux semaines si bien toléré. la niacinamide va aussi préparer la peau à recevoir le rétinal qui arrive.

### semaines 7-8 · introduire le rétinal

introduire le rétinal une fois par semaine, le soir. monter à deux fois la semaine suivante si la peau ne pique pas. technique sandwich : crème, attendre 30 secondes, rétinal, attendre 60 secondes, crème par-dessus. cette superposition réduit l'irritation rétinoïde mesurée.

### semaines 9-12 · compléter la cascade

ajouter les peptides ou le bakuchiol en alternance avec le rétinal. introduire les masques hebdomadaires (PHA et hydratant). c'est le moment où la routine est complète et où la peau commence à donner les premiers signaux mesurables.

![calendrier sur 12 semaines d'introduction progressive des actifs, grille en lignes horizontales par actif, palette pêche sonagi.](/assets/diagrams/routine-anti-age-12-week-calendar.svg)

*12 semaines pour intégrer toute la cascade sans saturer la barrière.*

## comment savoir que ça marche

les signaux mesurables, pas seulement « ma peau est plus belle ». le ressenti est notoirement biaisé par l'effet placebo et l'humeur du jour.

- **TEWL** (perte d'eau transépidermique) à mesurer en clinique avant le démarrage puis à 12 semaines. une baisse de 15 à 25 % traduit une barrière réparée.
- **élasticité cutométrique** mesurée par cutomètre. évolution attendue à 6 mois si rétinal et peptides sont bien intégrés.
- **photo-tracking en lumière constante**. même angle, même heure, même éclairage toutes les 4 semaines. c'est le juge le plus accessible et le moins biaisé.

### le protocole photo-tracking

photo de profil gauche, profil droit, face, et un zoom sur le contour de l'œil. lumière du nord à 14 heures (constante, sans contre-jour), fond uni clair, pas de maquillage, cheveux attachés. toutes les 4 semaines, même téléphone, même distance. tu reverras tes premières photos à 12 semaines et la différence sera là. si elle n'y est pas, on reprend le protocole.

### les signaux d'alerte

à surveiller : flush qui dure plus de 30 minutes après application, desquamation persistante au-delà de 7 jours sur le rétinal, démangeaisons récurrentes, irritation au coin du nez ou des paupières. stop, retour aux étapes barrière (nettoyage, toner, crème, spf) pendant 7 à 14 jours, puis ré-introduction des actifs un par un. si ça persiste, consulter ton dermatologue.

## le mot d'asma

> `[ANECDOTE — Asma personalize]`
>
> stub à compléter par asma. quelques cadres possibles à adapter :
>
> - l'âge où tu as basculé d'une routine glow à une routine anti-âge structurée. le déclic.
> - le rétinol que tu as commencé puis arrêté (et pourquoi tu es passée au rétinal : irritation, lenteur, ou les deux).
> - l'erreur la plus fréquente que tu vois sur les peaux 35+ en consultation : trop d'actifs, pas assez de barrière.
> - le moment où tu as compris que le spf, c'est 80 % du job. l'avant-après d'une cliente qui a juste mis un spf tous les jours pendant un an.
> - ton calendrier perso d'introduction quand tu prépares une cliente pour son protocole anti-âge ou pré-sculptra.

## le rituel anti-âge

sept pièces, douze semaines, un protocole. le pack sélectionné par notre équipe à séoul pour démarrer un anti-âge k-beauty sans tâtonner.

1. beauty of joseon · ginseng cleansing oil
2. cosrx · low pH good morning cleanser
3. anua · heartleaf 77 soothing toner
4. beauty of joseon · glow serum (vitamine C)
5. cosrx · the niacinamide 15 serum
6. a.true · retinal
7. beauty of joseon · relief sun spf50+

prix individuel : 178,40 €. prix rituel : 148,00 €. économie : 17 %.

`[CTA — bundle SKU: rituel-anti-age]`

## tes questions

### à partir de quel âge commencer une routine anti-âge ?

le spf quotidien, dès 20 ans. la structure complète (rétinal, peptides, essence fermentée) à partir de 35 ans, quand les premiers signaux mesurables apparaissent : ridules superficielles, perte d'élasticité cutométrique, taches solaires. avant 35, l'investissement le plus rentable reste le spf 50 et l'hydratation barrière. empiler les actifs trop tôt fatigue la peau pour rien.

### rétinol ou rétinal : quelle différence pour un débutant ?

le rétinal (rétinaldéhyde) est une étape métabolique plus proche de l'acide rétinoïque actif que le rétinol. résultat : efficacité comparable à dose équivalente, irritation moindre, action plus rapide. pour démarrer, un rétinal à 0,05 % deux soirs par semaine est mieux toléré qu'un rétinol à 0,3 %. si la peau pique malgré tout, repasser au bakuchiol en alternance.

### niacinamide ou rétinol en premier dans la cascade ?

niacinamide d'abord, rétinol ensuite. la niacinamide à 5 % en couche fine, attendre 60 secondes, puis le rétinol par-dessus. cette séquence est documentée pour réduire l'irritation rétinoïde tout en additionnant deux bénéfices anti-âge distincts (barrière et renouvellement). dans le calendrier sur 12 semaines, la niacinamide entre en semaine 5, le rétinal en semaine 7.

### combien de temps avant un résultat visible ?

trois à six mois pour les premiers signaux mesurables (TEWL, élasticité, atténuation des taches). douze mois pour la transformation visible. le protocole anti-âge n'est pas un sprint : c'est un investissement biologique sur une année minimum. photo-tracker toutes les 4 semaines en lumière constante reste le juge le plus fiable. la mémoire visuelle quotidienne est trop biaisée pour mesurer le progrès.

### peut-on faire une routine anti-âge enceinte ou allaitante ?

pas avec rétinal ni rétinol : les rétinoïdes sont contre-indiqués pendant la grossesse et l'allaitement. le bakuchiol est l'alternative la mieux documentée comme substitut. niacinamide, peptides, vitamine c, acide hyaluronique et spf restent compatibles. demande validation à ton médecin pour ton protocole personnel. c'est un réflexe que nous recommandons systématiquement quand une grossesse est suivie.

### la vitamine C en sérum, c'est vraiment indispensable ?

pas indispensable, mais fortement recommandée. antioxydant qui neutralise les radicaux libres générés par les UV, elle multiplie par deux à quatre la photoprotection cellulaire de ton spf. à 10-15 % de LAA stable, deux à trois mois suffisent pour mesurer une amélioration de l'éclat et une atténuation des taches débutantes. si la peau ne supporte pas le LAA, opter pour un dérivé stable type ascorbyl glucoside.

### peut-on combiner cette routine avec rejuran ou botox ?

oui, ce sont des leviers complémentaires. le rejuran (PDRN) répare la matrice dermique en injection toutes les 4 semaines sur trois séances. ta routine topique soutient le résultat entre les rendez-vous. le botox cible la dynamique musculaire des rides d'expression, ta routine cible la qualité de peau. les deux travaillent à des étages différents et se renforcent. à valider avec ton praticien selon le protocole de ta clinique.

### que faire si ma peau pique au rétinal ?

repasser à une fréquence inférieure : si tu étais à 3 soirs par semaine, redescendre à 1 soir. utiliser la technique sandwich (crème avant et après le rétinal). vérifier que la niacinamide est bien en place depuis au moins deux semaines avant le rétinal. si ça persiste après 14 jours, substituer par le bakuchiol pendant 4 semaines puis ré-essayer. la peau a parfois besoin d'un sas plus long que les 12 semaines du calendrier standard.

### faut-il continuer la routine pendant l'été ?

oui, avec deux ajustements. le rétinal peut être réduit à 1 fois par semaine au plus chaud, parce que la photosensibilisation et la transpiration augmentent le risque d'irritation. le spf devient encore plus critique : réapplication toutes les 2 heures en exposition, et après la baignade. la vitamine c et la niacinamide restent inchangées : elles sont plutôt utiles en saison UV.

## à lire ensuite

- [niacinamide · 나이아신아마이드](/content/ingredients/fr/niacinamide.md) · l'actif barrière qui rend le rétinal tolérable sur la durée.
- [glass skin · 물광](/content/techniques/fr/glass-skin.md) · le rendu mool-gwang qu'on cherche aussi à 50 ans.
- [rejuran · PDRN](/content/techniques/fr/rejuran-pdrn.md) · le levier en cabinet qui démultiplie ta routine topique.

---

*entry status : v0.1 draft. requires asma personalisation in `[ANECDOTE — Asma personalize]` block. all `[CITATION — verify PubMed]` markers must be replaced with verified PubMed IDs before publish per Sonagi Reference Programme rules. human review required before publication.*
