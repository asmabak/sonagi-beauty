# images to fetch from Higgsfield

This manifest lists every image referenced by the 4 encyclopedia entries, with its Higgsfield job ID and target path in this repository. The Claude Code sandbox blocks outbound network to `d8j0ntlcm91z4.cloudfront.net`, so Asma (or a Claude session with network access to Higgsfield's CDN) must fetch the bytes via the Higgsfield UI and drop them into the paths below.

**How to fetch:**

1. Open Higgsfield (logged in as the Sonagi account)
2. For each job ID, navigate to your history and download the original at 4K (`rawUrl`, not the `_min.webp` preview)
3. Rename to the target filename exactly
4. Drop into the matching folder. Build pipeline (`scripts/optimize-image.py`) will generate WebP + @2x + @3x variants on next CI run.
5. The original PNG goes into `_originals/` next to the WebP target path.

All job IDs verified active in the Higgsfield account as of 2026-05-15 via `job_display`. CloudFront URLs may continue to work in your browser even though they are blocked from this sandbox.

---

## niacinamide (ingredient)

| Higgsfield job ID | target path | resolution | notes |
|---|---|---|---|
| `cc11b916-797c-436e-ac48-f5e131ab9b25` | `assets/images/ingredients/niacinamide-hero.webp` | 4k 4:5 | hero. anua niacinamide 10 + TXA 4. banana yellow. full laugh, dollop on cheek. |
| `cc11b916-797c-436e-ac48-f5e131ab9b25` | `assets/images/ingredients/niacinamide-anua.webp` | 4k 4:5 | same image, also used as Anua product shot in `## les sérums niacinamide recommandés`. |
| `c2264a64-c77b-486c-9462-d0fad39c0030` | `assets/images/ingredients/niacinamide-cosrx.webp` | 4k 4:5 | COSRX the niacinamide 15. mint green. dropper, suspended drop, cheek dollops. |
| `8c80d824-a2d7-4f9f-9546-e859efebf554` | `assets/images/ingredients/niacinamide-glow-recipe.webp` | **1k** 4:5 | glow recipe watermelon dew drops. hot pink. **regenerate at 4k recommended.** |
| `9df26908-0f50-4a15-a4a4-724dce9362a2` | `assets/diagrams/skin-cross-section.png` | 4k 4:3 | epidermis cross-section. clean, no labels. **reusable across niacinamide / glass-skin / ceramides / retinal / vitamine-c / acide-hyaluronique entries** per spec section 5.2. label overlays added via HTML/SVG component. |

## glass-skin (technique)

| Higgsfield job ID | target path | resolution | notes |
|---|---|---|---|
| `67c8d9d8-aafa-4db9-a28a-319fb66b0656` | `assets/images/techniques/glass-skin-hero.webp` | 4k 3:2 | hero. maghrebi mid-tone golden honey. mool-gwang state. **primary.** |
| `cb60defb-a855-4b1b-9e03-2789c73f1089` | `assets/images/techniques/glass-skin-hero-alt.webp` | 4k 3:2 | alt take, same model. backup for editorial flow. |
| `272d99a9-dbf3-45dd-b8bb-722fbb0f03d5` | `assets/images/techniques/glass-skin-macro-proof.webp` | 4k 1:1 | extreme cheekbone macro. visual proof of texture. |
| `6ac90250-b2d0-4dc8-97ab-8020e5cf7f8b` | `assets/diagrams/glass-skin-mechanism.png` | 4k 4:3 | medical illustration, mool-gwang specific. clean, no labels. |
| `4cdf6536-3389-4bb1-9012-5f166442279b` | `assets/diagrams/glass-skin-mechanism-alt.png` | 4k 4:3 | alt version of mechanism illustration. |
| `2542b873-9c96-4369-b9d6-395169e3904a` | `assets/diagrams/glass-skin-infographic.png` | 4k 4:5 | scientific infographic, same visual register. |
| `8b91a9a4-319e-4dcd-b6cc-84bb5e54a92b` | `assets/images/techniques/glass-skin-flatlay-rituel.webp` | 4k 16:9 | complete glass skin ritual flatlay. used in `## le rituel glass skin` CTA. |
| `9ab8c1cf-2d5f-4f66-a693-2c1cebf0a646` | `assets/images/techniques/glass-skin-routine-flatlay.webp` | 4k 16:9 | alt 7-step lineup flatlay. |

## rejuran-pdrn (technique / clinical procedure)

| Higgsfield job ID | target path | resolution | notes |
|---|---|---|---|
| (none generated) | `assets/images/techniques/rejuran-pdrn-hero.webp` | — | **TO GENERATE.** casting per spec: mature 40+ Asian. clinical-but-warm editorial. follow `sonagi-beauty-skill.md` six-layer protocol. |
| (none generated) | `assets/diagrams/dermal-injection-depth.png` | — | **TO GENERATE.** dermal injection layer diagram (epidermis vs dermis vs subcutaneous), clean, no labels. reusable for sculptra / botox / mesotherapy entries. |
| (none generated) | `assets/diagrams/rejuran-protocol-timeline.png` | — | **TO GENERATE.** 4-session protocol timeline (S1 → S4 → maintenance). |

## routine-anti-age (routine)

| Higgsfield job ID | target path | resolution | notes |
|---|---|---|---|
| `ec30a5e2-a50d-43b6-bdb4-02f4a06de2f5` | `assets/images/routines/routine-anti-age-hero.webp` | 4k 4:5 | hero. radiant confident woman. K-beauty editorial register. |
| `1778137d-f9fe-4e26-8b13-ad5b0ef8047e` | `assets/images/routines/routine-anti-age-application.webp` | 4k 4:5 | application moment, ritual hero. |
| `b3fd4a3e-f333-4989-9182-032cb7dc4e97` | `assets/images/routines/routine-anti-age-mature.webp` | 4k 4:5 | mature woman portrait, fine lines preserved. |
| `8e73a691-4d96-4ff6-97eb-0743844e54b6` | `assets/images/routines/routine-anti-age-eye-cream.webp` | 4k 4:5 | eye cream patted into outer orbital with ring finger. ritual gesture. |
| `8b1e8df1-0869-4a36-982d-a0c0b82f09d9` | `assets/images/routines/routine-anti-age-eye-cream-2.webp` | 4k 4:5 | eye cream application alt. |
| `c1ba8491-108a-45b8-9cc7-3a0357952323` | `assets/images/routines/routine-anti-age-undereye.webp` | 4k 4:5 | undereye skin study, quiet moment before applying. |
| `6f078bcd-5888-4a1e-9104-24ec71cc4355` | `assets/images/routines/routine-anti-age-macro-fine-lines.webp` | 4k 16:9 | macro fine-line topography. anatomical reverence. |
| `c38eb25e-4e5b-4471-951d-6d546bfe35d9` | `assets/images/routines/routine-anti-age-macro-fine-lines-2.webp` | 4k 16:9 | macro fine-line alt. |
| `41866c60-cfad-4b73-aaab-b3561be4c226` | `assets/diagrams/underskin-cross-section-photorealistic.png` | 4k 16:9 | photorealistic anatomical cross-section. premium dermatology atlas register. **reusable across all anti-âge / collagen-related entries.** |
| (none generated) | `assets/diagrams/routine-anti-age-morning.svg` | — | **TO GENERATE or hand-draw in Figma.** numbered 5-step morning timeline SVG per Image & Diagram Protocol section 5.2. |
| (none generated) | `assets/diagrams/routine-anti-age-evening.svg` | — | **TO GENERATE or hand-draw in Figma.** numbered 7-step evening timeline SVG. |
| (none generated) | `assets/diagrams/routine-anti-age-12-week-calendar.svg` | — | **TO GENERATE or hand-draw in Figma.** 12-week introduction calendar SVG. |

---

## what's missing (needs new generation)

Before the 4 entries ship, the following images need to be created:

**rejuran-pdrn page** (3 images):
- hero (mature 40+ Asian, clinical editorial)
- dermal injection depth diagram (reusable for sculptra, botox, mesotherapy)
- protocol timeline (4 sessions + maintenance)

**routine-anti-age page** (3 diagrams):
- 5-step morning routine timeline SVG (Figma)
- 7-step evening routine timeline SVG (Figma)
- 12-week introduction calendar SVG (Figma)

**niacinamide page** (1 image, optional improvement):
- hero at 4k. current candidate `8c80d824` is only 1k. recommend regeneration at 4k with same prompt OR substitute `cc11b916` (already 4k, currently set as both hero + Anua product shot).

Generations are paid (Higgsfield credits). Estimate at `count: 1` per image per spec: ~6 new generations needed. Ask Asma to approve credit spend before generation.

---

## fetch checklist for Asma

- [ ] niacinamide-hero.webp (cc11b916)
- [ ] niacinamide-anua.webp (cc11b916, same file)
- [ ] niacinamide-cosrx.webp (c2264a64)
- [ ] niacinamide-glow-recipe.webp (8c80d824 OR regenerate)
- [ ] skin-cross-section.png (9df26908)
- [ ] glass-skin-hero.webp (67c8d9d8)
- [ ] glass-skin-hero-alt.webp (cb60defb)
- [ ] glass-skin-macro-proof.webp (272d99a9)
- [ ] glass-skin-mechanism.png (6ac90250)
- [ ] glass-skin-mechanism-alt.png (4cdf6536)
- [ ] glass-skin-infographic.png (2542b873)
- [ ] glass-skin-flatlay-rituel.webp (8b91a9a4)
- [ ] glass-skin-routine-flatlay.webp (9ab8c1cf)
- [ ] routine-anti-age-hero.webp (ec30a5e2)
- [ ] routine-anti-age-application.webp (1778137d)
- [ ] routine-anti-age-mature.webp (b3fd4a3e)
- [ ] routine-anti-age-eye-cream.webp (8e73a691)
- [ ] routine-anti-age-eye-cream-2.webp (8b1e8df1)
- [ ] routine-anti-age-undereye.webp (c1ba8491)
- [ ] routine-anti-age-macro-fine-lines.webp (6f078bcd)
- [ ] routine-anti-age-macro-fine-lines-2.webp (c38eb25e)
- [ ] underskin-cross-section-photorealistic.png (41866c60)
- [ ] rejuran-pdrn-hero.webp (**generate**)
- [ ] dermal-injection-depth.png (**generate**)
- [ ] rejuran-protocol-timeline.png (**generate**)
- [ ] routine-anti-age-morning.svg (**design in Figma**)
- [ ] routine-anti-age-evening.svg (**design in Figma**)
- [ ] routine-anti-age-12-week-calendar.svg (**design in Figma**)

For each fetched image: also create a sidecar JSON file (same base name, `.json` extension) per Image & Diagram Protocol section "Step 3: Write sidecar metadata". Example sidecar at `assets/images/ingredients/niacinamide-hero.json`.
